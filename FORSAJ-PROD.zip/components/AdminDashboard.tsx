import React, { useState } from 'react';
import { useAdmin, Driver, NewsItem, EventItem, GallerySection } from '../context/AdminContext';
import { useLanguage } from '../context/LanguageContext';
import {
    Settings, Users, LogOut, Check, X, Edit2, Save, Plus, Trash2,
    Globe, Image as ImageIcon, Newspaper, Calendar, LayoutGrid, PlusCircle
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
    const {
        settings, updateSettings, drivers, saveDriver, deleteDriver,
        news, saveNews, deleteNews,
        events, saveEvent, deleteEvent,
        gallery, saveGallery, deleteGallery,
        currentUser, logout, login
    } = useAdmin();

    const { translations, updateTranslation } = useLanguage();
    const [activeTab, setActiveTab] = useState<'settings' | 'drivers' | 'news' | 'events' | 'gallery' | 'words'>('settings');
    const [loginData, setLoginData] = useState({ username: '', password: '' });

    // Edit States
    const [editingDriver, setEditingDriver] = useState<Partial<Driver> | null>(null);
    const [editingNews, setEditingNews] = useState<Partial<NewsItem> | null>(null);
    const [editingEvent, setEditingEvent] = useState<Partial<EventItem> | null>(null);
    const [editingGallery, setEditingGallery] = useState<Partial<GallerySection> | null>(null);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        const success = await login(loginData.username, loginData.password);
        if (!success) alert('Giriş alınmadı: Yanlış istifadəçi adı və ya şifrə');
    };

    if (!currentUser) {
        return (
            <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-6 text-white font-['Inter']">
                <div className="w-full max-w-md bg-[#111] border border-white/10 p-10 rounded-sm shadow-2xl">
                    <div className="flex items-center gap-4 mb-10">
                        <div className="w-1.5 h-10 bg-[#FF4D00]"></div>
                        <h1 className="text-3xl font-black italic uppercase tracking-tighter">Admin Giriş</h1>
                    </div>
                    <form onSubmit={handleLogin} className="space-y-6">
                        <div>
                            <label className="block text-gray-500 font-black italic text-[10px] uppercase tracking-widest mb-2">İstifadəçi Adı</label>
                            <input type="text" value={loginData.username} onChange={(e) => setLoginData({ ...loginData, username: e.target.value })} className="w-full bg-black border border-white/10 p-4 text-white font-bold focus:border-[#FF4D00] outline-none transition-colors" />
                        </div>
                        <div>
                            <label className="block text-gray-500 font-black italic text-[10px] uppercase tracking-widest mb-2">Şifrə</label>
                            <input type="password" value={loginData.password} onChange={(e) => setLoginData({ ...loginData, password: e.target.value })} className="w-full bg-black border border-white/10 p-4 text-white font-bold focus:border-[#FF4D00] outline-none transition-colors" />
                        </div>
                        <button type="submit" className="w-full bg-[#FF4D00] text-black font-black italic py-4 uppercase tracking-widest hover:bg-white transition-colors">DAXİL OL</button>
                    </form>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#0A0A0A] text-white flex font-['Inter']">
            {/* Sidebar */}
            <div className="w-80 bg-[#111] border-r border-white/5 flex flex-col sticky top-0 h-screen">
                <div className="p-8 border-b border-white/5">
                    <h2 className="text-xl font-black italic text-[#FF4D00] uppercase tracking-tighter">FORSAJ CMS</h2>
                    <p className="text-[10px] text-gray-500 font-bold uppercase mt-1 tracking-widest">{currentUser.role} // {currentUser.username}</p>
                </div>

                <nav className="flex-grow p-4 space-y-2 overflow-y-auto">
                    {[
                        { id: 'settings', icon: Settings, label: 'SAYT AYARLARI' },
                        { id: 'drivers', icon: Users, label: 'SÜRÜCÜLƏR' },
                        { id: 'news', icon: Newspaper, label: 'XƏBƏRLƏR' },
                        { id: 'events', icon: Calendar, label: 'TƏDBİRLƏR' },
                        { id: 'gallery', icon: LayoutGrid, label: 'QALEREYA' },
                        { id: 'words', icon: Globe, label: 'SÖZLƏR (CMS)' }
                    ].map(tab => (
                        <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`w-full flex items-center gap-4 p-4 font-black italic uppercase text-xs tracking-widest transition-all ${activeTab === tab.id ? 'bg-[#FF4D00] text-black' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
                            <tab.icon size={18} /> {tab.label}
                        </button>
                    ))}
                </nav>

                <button onClick={logout} className="m-4 flex items-center gap-4 p-4 font-black italic uppercase text-xs tracking-widest text-red-500 hover:bg-red-500/10 transition-all border border-red-500/20">
                    <LogOut size={18} /> ÇIXIŞ
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-grow p-12 overflow-y-auto">
                {activeTab === 'settings' && <SettingsTab settings={settings} updateSettings={updateSettings} isMaster={currentUser.role === 'master'} />}
                {activeTab === 'drivers' && <DriversTab drivers={drivers} onEdit={setEditingDriver} onDelete={deleteDriver} onAdd={() => setEditingDriver({ name: '', points: 0, category: 'UNLIMITED', team: '', car: '' })} />}
                {activeTab === 'news' && <NewsTab news={news} onEdit={setEditingNews} onDelete={deleteNews} onAdd={() => setEditingNews({ title: '', category: '', description: '', date: new Date().toISOString().split('T')[0], isMain: false })} />}
                {activeTab === 'events' && <EventsTab events={events} onEdit={setEditingEvent} onDelete={deleteEvent} onAdd={() => setEditingEvent({ title: '', location: '', date: '', category: '', status: 'planned', description: '', rules: '' })} />}
                {activeTab === 'gallery' && <GalleryTab gallery={gallery} onEdit={setEditingGallery} onDelete={deleteGallery} onAdd={() => setEditingGallery({ title: '', date: '', photos: [], videos: [] })} />}
                {activeTab === 'words' && <WordsTab translations={translations} onUpdate={updateTranslation} />}

                {/* Modals */}
                {editingDriver && <DriverModal driver={editingDriver} onClose={() => setEditingDriver(null)} onSave={saveDriver} />}
                {editingNews && <NewsModal item={editingNews} onClose={() => setEditingNews(null)} onSave={saveNews} />}
                {editingEvent && <EventModal event={editingEvent} onClose={() => setEditingEvent(null)} onSave={saveEvent} />}
                {editingGallery && <GalleryModal section={editingGallery} onClose={() => setEditingGallery(null)} onSave={saveGallery} />}
            </div>
        </div>
    );
};

// --- GENERIC SECTION HEADER ---
const SectionHeader: React.FC<{ title: string, onAdd?: () => void, btnLabel?: string }> = ({ title, onAdd, btnLabel = "ƏLAVƏ ET" }) => (
    <div className="flex justify-between items-center mb-12">
        <div className="flex items-start gap-4">
            <div className="w-2 h-12 bg-[#FF4D00]"></div>
            <h2 className="text-5xl font-black italic uppercase tracking-tighter">{title}</h2>
        </div>
        {onAdd && (
            <button onClick={onAdd} className="bg-[#FF4D00] text-black px-8 py-4 font-black italic uppercase text-xs flex items-center gap-2 hover:bg-white transition-colors">
                <Plus size={18} /> {btnLabel}
            </button>
        )}
    </div>
);

// --- TABS ---

const SettingsTab: React.FC<{ settings: any, updateSettings: any, isMaster: boolean }> = ({ settings, updateSettings, isMaster }) => (
    <div className="space-y-12 max-w-4xl">
        <SectionHeader title="SAYT AYARLARI" />
        <div className="bg-[#111] border border-white/5 p-10 space-y-10">
            <div className="flex items-center justify-between">
                <div>
                    <h3 className="text-xl font-black italic uppercase mb-1">MARQUEE (ELAN) XƏTTİ</h3>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Baş səhifədəki hərəkətli zolaq</p>
                </div>
                <button disabled={!isMaster} onClick={() => updateSettings({ marqueeEnabled: !settings.marqueeEnabled })} className={`w-16 h-8 rounded-full relative transition-colors ${settings.marqueeEnabled ? 'bg-[#FF4D00]' : 'bg-gray-800'} ${!isMaster ? 'opacity-30' : ''}`}>
                    <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${settings.marqueeEnabled ? 'left-9' : 'left-1'}`}></div>
                </button>
            </div>
            <div className="space-y-4">
                <label className="text-[10px] text-gray-500 font-black uppercase tracking-widests">MARQUEE MƏTNİ</label>
                <textarea value={settings.marqueeText} onChange={e => updateSettings({ marqueeText: e.target.value })} disabled={!isMaster} className="w-full bg-black border border-white/10 p-6 text-white font-bold outline-none focus:border-[#FF4D00] min-h-[100px]" />
            </div>
        </div>
    </div>
);

const DriversTab: React.FC<{ drivers: Driver[], onEdit: any, onDelete: any, onAdd: any }> = ({ drivers, onEdit, onDelete, onAdd }) => (
    <div className="animate-in fade-in slide-in-from-left-4">
        <SectionHeader title="SÜRÜCÜLƏR" onAdd={onAdd} btnLabel="YENİ SÜRÜCÜ" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {drivers.map(driver => (
                <div key={driver.id} className="bg-[#111] border border-white/5 p-6 group hover:border-[#FF4D00]/50 transition-all">
                    <div className="flex items-center gap-6 mb-6">
                        <div className="w-20 h-20 bg-black overflow-hidden border border-white/10 grayscale group-hover:grayscale-0 transition-all">
                            <img src={driver.image} className="w-full h-full object-cover" alt="" />
                        </div>
                        <div>
                            <h4 className="text-xl font-black italic uppercase leading-none mb-2">{driver.name}</h4>
                            <p className="text-[10px] text-[#FF4D00] font-black italic uppercase tracking-widest">{driver.category} // {driver.car}</p>
                        </div>
                    </div>
                    <div className="flex justify-between items-end pt-6 border-t border-white/5">
                        <span className="text-3xl font-black italic">{driver.points} <span className="text-[10px] text-gray-600 uppercase">XAL</span></span>
                        <div className="flex gap-2">
                            <button onClick={() => onEdit(driver)} className="p-3 bg-white/5 text-gray-400 hover:text-[#FF4D00] transition-colors"><Edit2 size={16} /></button>
                            <button onClick={() => confirm('Silinsin?') && onDelete(driver.id)} className="p-3 bg-white/5 text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={16} /></button>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    </div>
);

const NewsTab: React.FC<{ news: NewsItem[], onEdit: any, onDelete: any, onAdd: any }> = ({ news, onEdit, onDelete, onAdd }) => (
    <div className="animate-in fade-in slide-in-from-left-4">
        <SectionHeader title="XƏBƏRLƏR" onAdd={onAdd} btnLabel="YENİ XƏBƏR" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {news.map(item => (
                <div key={item.id} className="bg-[#111] border border-white/5 p-8 flex gap-8 group hover:border-[#FF4D00]/50 transition-all">
                    <div className="w-48 aspect-video bg-black shrink-0 overflow-hidden border border-white/10 grayscale group-hover:grayscale-0 transition-all">
                        <img src={item.image} className="w-full h-full object-cover" alt="" />
                    </div>
                    <div className="flex-grow">
                        <div className="flex justify-between items-start mb-2">
                            <span className="text-[9px] text-[#FF4D00] font-black italic uppercase tracking-widest">{item.category} // {item.date}</span>
                            {item.isMain && <span className="text-[8px] bg-[#FF4D00] text-black px-2 py-0.5 font-black uppercase italic">ƏSAS</span>}
                        </div>
                        <h4 className="text-2xl font-black italic uppercase tracking-tighter mb-4 line-clamp-1">{item.title}</h4>
                        <div className="flex justify-end gap-2">
                            <button onClick={() => onEdit(item)} className="p-2 text-gray-500 hover:text-white transition-colors"><Edit2 size={16} /></button>
                            <button onClick={() => confirm('Silinsin?') && onDelete(item.id)} className="p-2 text-gray-500 hover:text-red-500 transition-colors"><Trash2 size={16} /></button>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    </div>
);

const EventsTab: React.FC<{ events: EventItem[], onEdit: any, onDelete: any, onAdd: any }> = ({ events, onEdit, onDelete, onAdd }) => (
    <div className="animate-in fade-in slide-in-from-left-4">
        <SectionHeader title="TƏDBİRLƏR" onAdd={onAdd} btnLabel="YENİ TƏDBİR" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            {events.map(event => (
                <div key={event.id} className="bg-[#111] border border-white/5 overflow-hidden group hover:border-[#FF4D00]/50 transition-all">
                    <div className="aspect-video bg-black relative grayscale group-hover:grayscale-0 transition-all">
                        <img src={event.img} className="w-full h-full object-cover" alt="" />
                        <div className={`absolute top-4 right-4 text-[8px] px-3 py-1 font-black italic uppercase ${event.status === 'planned' ? 'bg-[#FF4D00] text-black' : 'bg-gray-800 text-white'}`}>
                            {event.status === 'planned' ? 'GƏLƏCƏK' : 'BİTİB'}
                        </div>
                    </div>
                    <div className="p-6">
                        <h4 className="text-xl font-black italic uppercase mb-1 tracking-tighter line-clamp-1">{event.title}</h4>
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-6">{event.location} // {event.date}</p>
                        <div className="flex gap-2 justify-end border-t border-white/5 pt-4">
                            <button onClick={() => onEdit(event)} className="p-2 text-gray-500 hover:text-white transition-colors"><Edit2 size={16} /></button>
                            <button onClick={() => confirm('Silinsin?') && onDelete(event.id)} className="p-2 text-gray-500 hover:text-red-500 transition-colors"><Trash2 size={16} /></button>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    </div>
);

const GalleryTab: React.FC<{ gallery: GallerySection[], onEdit: any, onDelete: any, onAdd: any }> = ({ gallery, onEdit, onDelete, onAdd }) => (
    <div className="animate-in fade-in slide-in-from-left-4">
        <SectionHeader title="QALEREYA" onAdd={onAdd} btnLabel="EKSPEDİSİYA ƏLAVƏ ET" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {gallery.map(g => (
                <div key={g.id} className="bg-[#111] border border-white/5 p-8 group hover:border-[#FF4D00]/50 transition-all">
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <h4 className="text-3xl font-black italic uppercase tracking-tighter">{g.title}</h4>
                            <p className="text-xs text-[#FF4D00] font-black italic uppercase tracking-widest">{g.date}</p>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={() => onEdit(g)} className="p-2 text-gray-500 hover:text-white transition-colors"><Edit2 size={16} /></button>
                            <button onClick={() => confirm('Silinsin?') && onDelete(g.id)} className="p-2 text-gray-500 hover:text-red-500 transition-colors"><Trash2 size={16} /></button>
                        </div>
                    </div>
                    <div className="grid grid-cols-4 gap-2 opacity-40 group-hover:opacity-100 transition-opacity">
                        {g.photos.slice(0, 4).map((p, i) => (
                            <div key={i} className="aspect-square bg-black border border-white/10 overflow-hidden">
                                <img src={p.url} className="w-full h-full object-cover" alt="" />
                            </div>
                        ))}
                    </div>
                    <p className="text-[10px] text-gray-600 font-bold uppercase mt-4 tracking-widest">{g.photos.length} FOTO // {g.videos.length} VİDEO</p>
                </div>
            ))}
        </div>
    </div>
);

// --- MODALS ---

const ModalWrapper: React.FC<{ title: string, onClose: () => void, onSave: () => void, children: React.ReactNode }> = ({ title, onClose, onSave, children }) => (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-6 overflow-y-auto">
        <div className="bg-[#111] border border-white/10 w-full max-w-2xl my-auto p-10 space-y-8 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center bg-black/40 -m-10 p-10 mb-2 border-b border-white/5">
                <h3 className="text-2xl font-black italic uppercase tracking-tighter">{title}</h3>
                <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors"><X size={32} /></button>
            </div>
            {children}
            <button onClick={onSave} className="w-full bg-[#FF4D00] text-black font-black italic py-5 uppercase tracking-[0.2em] shadow-lg hover:bg-white transition-all transform active:scale-[0.98]">YADDA SAXLA (CMS UPDATE)</button>
        </div>
    </div>
);

const DriverModal: React.FC<{ driver: Partial<Driver>, onClose: () => void, onSave: any }> = ({ driver, onClose, onSave }) => {
    const [data, setData] = useState(driver);
    const [file, setFile] = useState<File | null>(null);
    return (
        <ModalWrapper title={driver.id ? "SÜRÜCÜ REDAKTƏ" : "YENİ SÜRÜCÜ"} onClose={onClose} onSave={() => onSave(data, file)}>
            <div className="grid grid-cols-2 gap-6">
                <Input label="AD SOYAD" value={data.name} onChange={v => setData({ ...data, name: v })} />
                <Select label="KATEQORİYA" value={data.category} options={['UNLIMITED', 'LEGEND', 'SEMI STOCK', 'UTV']} onChange={v => setData({ ...data, category: v as any })} />
                <Input label="XAL" type="number" value={data.points} onChange={v => setData({ ...data, points: parseInt(v) || 0 })} />
                <Input label="AVTOMOBİL" value={data.car} onChange={v => setData({ ...data, car: v })} />
                <div className="col-span-2"><FileInput label="SÜRÜCÜ ŞƏKLİ" preview={data.image} onChange={f => setFile(f)} /></div>
            </div>
        </ModalWrapper>
    );
};

const NewsModal: React.FC<{ item: Partial<NewsItem>, onClose: () => void, onSave: any }> = ({ item, onClose, onSave }) => {
    const [data, setData] = useState(item);
    const [file, setFile] = useState<File | null>(null);
    return (
        <ModalWrapper title="XƏBƏR REDAKTƏ" onClose={onClose} onSave={() => onSave(data, file)}>
            <div className="space-y-6">
                <Input label="BAŞLIQ" value={data.title} onChange={v => setData({ ...data, title: v })} />
                <div className="grid grid-cols-2 gap-6">
                    <Input label="KATEQORİYA" value={data.category} onChange={v => setData({ ...data, category: v })} />
                    <Input label="TARİX" type="date" value={data.date} onChange={v => setData({ ...data, date: v })} />
                </div>
                <textarea value={data.description} onChange={e => setData({ ...data, description: e.target.value })} className="w-full bg-black border border-white/10 p-4 font-bold min-h-[100px]" placeholder="XƏBƏR MƏTNİ..." />
                <div className="flex items-center gap-4">
                    <button onClick={() => setData({ ...data, isMain: !data.isMain })} className={`w-12 h-6 rounded-full relative ${data.isMain ? 'bg-[#FF4D00]' : 'bg-gray-800'}`}>
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${data.isMain ? 'left-7' : 'left-1'}`}></div>
                    </button>
                    <span className="text-[10px] font-black italic uppercase">ƏSAS XƏBƏR KİMİ QEYD ET</span>
                </div>
                <FileInput label="XƏBƏR ŞƏKLİ" preview={data.image} onChange={f => setFile(f)} />
            </div>
        </ModalWrapper>
    );
};

const EventModal: React.FC<{ event: Partial<EventItem>, onClose: () => void, onSave: any }> = ({ event, onClose, onSave }) => {
    const [data, setData] = useState(event);
    const [file, setFile] = useState<File | null>(null);
    return (
        <ModalWrapper title="TƏDBİR REDAKTƏ" onClose={onClose} onSave={() => onSave(data, file)}>
            <div className="space-y-6">
                <Input label="TƏDBİR ADI" value={data.title} onChange={v => setData({ ...data, title: v })} />
                <div className="grid grid-cols-2 gap-6">
                    <Input label="MƏKAN" value={data.location} onChange={v => setData({ ...data, location: v })} />
                    <Input label="TARİX" type="date" value={data.date} onChange={v => setData({ ...data, date: v })} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                    <Input label="KATEQORİYA" value={data.category} onChange={v => setData({ ...data, category: v })} />
                    <Select label="STATUS" value={data.status} options={['planned', 'past']} onChange={v => setData({ ...data, status: v as any })} />
                </div>
                <textarea value={data.description} onChange={e => setData({ ...data, description: e.target.value })} className="w-full bg-black border border-white/10 p-4 font-bold min-h-[80px]" placeholder="TƏSVİR..." />
                <textarea value={data.rules} onChange={e => setData({ ...data, rules: e.target.value })} className="w-full bg-black border border-white/10 p-4 font-bold min-h-[80px]" placeholder="QAYDALAR..." />
                <FileInput label="TƏDBİR ŞƏKLİ (POSTER)" preview={data.img} onChange={f => setFile(f)} />
            </div>
        </ModalWrapper>
    );
};

const GalleryModal: React.FC<{ section: Partial<GallerySection>, onClose: () => void, onSave: any }> = ({ section, onClose, onSave }) => {
    const [data, setData] = useState(section);
    return (
        <ModalWrapper title="QALEREYA / EKSPEDİSİYA" onClose={onClose} onSave={() => onSave(data)}>
            <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                    <Input label="BAŞLIQ" value={data.title} onChange={v => setData({ ...data, title: v })} />
                    <Input label="TARİX" value={data.date} onChange={v => setData({ ...data, date: v })} />
                </div>
                <div className="bg-black/50 p-6 border border-white/5 space-y-4">
                    <h5 className="text-[10px] text-[#FF4D00] font-black italic tracking-widest uppercase">FOTOLAR (JSON URL)</h5>
                    <p className="text-[9px] text-gray-600 uppercase">Hazırda URL vasitəsilə əlavə olunur</p>
                    <textarea
                        value={JSON.stringify(data.photos, null, 2)}
                        onChange={e => { try { setData({ ...data, photos: JSON.parse(e.target.value) }); } catch (e) { } }}
                        className="w-full bg-black p-4 text-[10px] font-mono min-h-[150px] text-gray-400"
                    />
                </div>
            </div>
        </ModalWrapper>
    );
};

// --- CMS WORDS TAB ---
const WordsTab: React.FC<{ translations: any, onUpdate: any }> = ({ translations, onUpdate }) => {
    const [search, setSearch] = useState('');
    const [editingKey, setEditingKey] = useState<string | null>(null);
    const [editValues, setEditValues] = useState({ AZ: '', EN: '', RU: '' });

    const filteredKeys = Object.keys(translations).filter(key =>
        key.toLowerCase().includes(search.toLowerCase()) ||
        translations[key].AZ.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="space-y-12 animate-in fade-in slide-in-from-left-4">
            <SectionHeader title="SÖZLƏR (CMS)" />
            <div className="bg-[#111] p-8 border border-white/5">
                <input type="text" placeholder="SÖZ VƏ YA KEY AXTAR..." value={search} onChange={e => setSearch(e.target.value)} className="w-full bg-black border border-white/10 p-4 font-bold text-white outline-none focus:border-[#FF4D00]" />
            </div>
            <div className="space-y-4">
                {filteredKeys.map(key => (
                    <div key={key} className="bg-[#111] border border-white/5 p-6 hover:bg-[#151515] transition-colors">
                        <div className="flex justify-between items-start mb-6">
                            <span className="text-[10px] text-[#FF4D00] font-black italic tracking-widest uppercase">{key}</span>
                            {editingKey === key ? (
                                <div className="flex gap-2">
                                    <button onClick={() => setEditingKey(null)} className="p-2 text-gray-500"><X size={18} /></button>
                                    <button onClick={() => { onUpdate(key, editValues); setEditingKey(null); }} className="p-2 text-[#FF4D00]"><Save size={18} /></button>
                                </div>
                            ) : (
                                <button onClick={() => { setEditingKey(key); setEditValues(translations[key]); }} className="p-2 text-gray-500 hover:text-white"><Edit2 size={18} /></button>
                            )}
                        </div>
                        <div className="grid grid-cols-3 gap-6">
                            {['AZ', 'EN', 'RU'].map(lang => (
                                <div key={lang} className="space-y-2">
                                    <p className="text-[9px] text-gray-600 font-bold uppercase">{lang}</p>
                                    {editingKey === key ? (
                                        <input value={editValues[lang as keyof typeof editValues]} onChange={e => setEditValues({ ...editValues, [lang]: e.target.value })} className="w-full bg-black border border-white/10 p-3 text-xs font-bold" />
                                    ) : (
                                        <p className="text-xs font-bold">{translations[key][lang]}</p>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

// --- HELPER UI ---
const Input: React.FC<{ label: string, value: any, onChange: (v: string) => void, type?: string }> = ({ label, value, onChange, type = "text" }) => (
    <div className="space-y-2">
        <label className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{label}</label>
        <input type={type} value={value} onChange={e => onChange(e.target.value)} className="w-full bg-black border border-white/10 p-4 font-bold outline-none focus:border-[#FF4D00]" />
    </div>
);

const Select: React.FC<{ label: string, value: string, options: string[], onChange: (v: string) => void }> = ({ label, value, options, onChange }) => (
    <div className="space-y-2">
        <label className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{label}</label>
        <select value={value} onChange={e => onChange(e.target.value)} className="w-full bg-black border border-white/10 p-4 font-bold outline-none focus:border-[#FF4D00] appearance-none uppercase">
            {options.map(o => <option key={o} value={o}>{o.toUpperCase()}</option>)}
        </select>
    </div>
);

const FileInput: React.FC<{ label: string, preview?: string, onChange: (f: File) => void }> = ({ label, preview, onChange }) => {
    const [localPrev, setLocalPrev] = useState(preview);
    return (
        <div className="space-y-4">
            <label className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{label}</label>
            <div className="flex gap-6 items-center">
                <div className="w-32 aspect-video bg-black border border-white/10 flex items-center justify-center overflow-hidden">
                    {localPrev ? <img src={localPrev} className="w-full h-full object-cover" alt="" /> : <ImageIcon className="text-gray-800" size={32} />}
                </div>
                <div className="flex-grow">
                    <input type="file" id="file-up" className="hidden" onChange={e => { if (e.target.files?.[0]) { onChange(e.target.files[0]); setLocalPrev(URL.createObjectURL(e.target.files[0])); } }} />
                    <label htmlFor="file-up" className="block w-full text-center bg-white/5 border border-white/10 p-4 font-black italic text-[10px] uppercase tracking-widest cursor-pointer hover:bg-white/10">ŞƏKİL SEÇİN</label>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
