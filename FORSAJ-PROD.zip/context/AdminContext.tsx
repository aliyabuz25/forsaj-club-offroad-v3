import React, { createContext, useContext, useState, ReactNode } from 'react';
import usersData from '../json/users.json';

// Types
export interface Driver {
    id: string;
    name: string;
    category: 'UNLIMITED' | 'LEGEND' | 'SEMI STOCK' | 'UTV';
    points: number;
    car: string;
    image?: string;
    team?: string;
}

export interface NewsItem {
    id: string;
    title: string;
    description: string;
    date: string;
    image: string;
    category: string;
    isMain?: boolean;
}

export interface EventItem {
    id: string;
    title: string;
    date: string;
    location: string;
    category: string;
    img: string;
    description?: string;
    rules?: string;
    status: 'planned' | 'past';
}

export interface GallerySection {
    id: string;
    title: string;
    date: string;
    photos: { id: string, title: string, url: string }[];
    videos: { id: string, title: string, videoId: string, duration: string, url: string }[];
}

export interface AdminSettings {
    marqueeEnabled: boolean;
    marqueeText: string;
}

export interface AdminUser {
    username: string;
    role: 'master' | 'secondary';
}

interface AdminContextType {
    settings: AdminSettings;
    updateSettings: (newSettings: Partial<AdminSettings>) => Promise<void>;
    drivers: Driver[];
    news: NewsItem[];
    events: EventItem[];
    gallery: GallerySection[];
    saveDriver: (driver: Partial<Driver>, imageFile?: File) => Promise<void>;
    deleteDriver: (id: string) => Promise<void>;
    updateDriverPoints: (id: string, points: number) => Promise<void>;
    saveNews: (item: Partial<NewsItem>, imageFile?: File) => Promise<void>;
    deleteNews: (id: string) => Promise<void>;
    saveEvent: (item: Partial<EventItem>, imageFile?: File) => Promise<void>;
    deleteEvent: (id: string) => Promise<void>;
    saveGallery: (section: Partial<GallerySection>, imageFile?: File) => Promise<void>;
    deleteGallery: (id: string) => Promise<void>;
    currentUser: AdminUser | null;
    login: (username: string, password: string) => Promise<boolean>;
    logout: () => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [settings, setSettings] = useState<AdminSettings>({ marqueeEnabled: true, marqueeText: "" });
    const [drivers, setDrivers] = useState<Driver[]>([]);
    const [news, setNews] = useState<NewsItem[]>([]);
    const [events, setEvents] = useState<EventItem[]>([]);
    const [gallery, setGallery] = useState<GallerySection[]>([]);
    const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

    // Initial load
    React.useEffect(() => {
        fetch('/api/settings').then(res => res.json()).then(setSettings);
        fetch('/api/drivers').then(res => res.json()).then(setDrivers);
        fetch('/api/news').then(res => res.json()).then(setNews);
        fetch('/api/events').then(res => res.json()).then(setEvents);
        fetch('/api/gallery').then(res => res.json()).then(setGallery);
    }, []);

    const updateSettings = async (newSettings: Partial<AdminSettings>) => {
        const updated = { ...settings, ...newSettings };
        const res = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updated)
        });
        if (res.ok) setSettings(updated);
    };

    const saveEntity = async (entity: string, data: any, file?: File, setter?: any) => {
        const formData = new FormData();
        formData.append('data', JSON.stringify(data));
        if (file) formData.append('image', file);
        const res = await fetch(`/api/${entity}`, { method: 'POST', body: formData });
        if (res.ok) fetch(`/api/${entity}`).then(r => r.json()).then(setter);
    };

    const deleteEntity = async (entity: string, id: string, setter?: any) => {
        const res = await fetch(`/api/${entity}/${id}`, { method: 'DELETE' });
        if (res.ok) fetch(`/api/${entity}`).then(r => r.json()).then(setter);
    };

    const saveDriver = (data: any, file?: File) => saveEntity('drivers', data, file, setDrivers);
    const deleteDriver = (id: string) => deleteEntity('drivers', id, setDrivers);
    const updateDriverPoints = async (id: string, newPoints: number) => {
        const d = drivers.find(x => x.id === id);
        if (d) await saveDriver({ ...d, points: newPoints });
    };

    const saveNews = (data: any, file?: File) => saveEntity('news', data, file, setNews);
    const deleteNews = (id: string) => deleteEntity('news', id, setNews);

    const saveEvent = (data: any, file?: File) => saveEntity('events', data, file, setEvents);
    const deleteEvent = (id: string) => deleteEntity('events', id, setEvents);

    const saveGallery = (data: any, file?: File) => saveEntity('gallery', data, file, setGallery);
    const deleteGallery = (id: string) => deleteEntity('gallery', id, setGallery);

    const login = async (username: string, password: string): Promise<boolean> => {
        try {
            const users = await fetch('/api/users').then(res => res.json());
            const user = users.find((u: any) => u.username === username && u.password === password);
            if (user) {
                setCurrentUser({ username: user.username, role: user.role as 'master' | 'secondary' });
                return true;
            }
            return false;
        } catch (error) {
            console.error(error);
            return false;
        }
    };

    const logout = () => setCurrentUser(null);

    return (
        <AdminContext.Provider value={{
            settings, updateSettings, drivers, news, events, gallery,
            saveDriver, deleteDriver, updateDriverPoints,
            saveNews, deleteNews, saveEvent, deleteEvent, saveGallery, deleteGallery,
            currentUser, login, logout
        }}>
            {children}
        </AdminContext.Provider>
    );
};

export const useAdmin = () => {
    const context = useContext(AdminContext);
    if (context === undefined) {
        throw new Error('useAdmin must be used within an AdminProvider');
    }
    return context;
};
